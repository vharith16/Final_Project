#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MIN_RATING 4
#define MAX_RATING 12

// Function to calculate rating based on the number of wins and losses
int calculate_rating(int wins, int losses, int position) {
    int rating;
    if (position == 1) {
        rating = (int)(wins * 1.5) - losses;
    } else if (position == 2) {
        rating = (int)(wins * 1.2) - losses; 
    } else {
        rating = wins - (int)(losses * 1.5);
    }
    if (rating <= MIN_RATING) {
        return MIN_RATING;
    } else if (rating >= MAX_RATING) {
        return MAX_RATING;
    } else {
        return rating;
    }
}

// We construct the filename by concatenating the player name with ".txt". Then, we use the fopen() function to open the file with that name.
void update_rating(char* player_name) {
    char filename[50];
    sprintf(filename, "%s.txt", player_name); // Construct the filename by concatenating the player name with ".txt"
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file %s\n", filename);
        return;
    } 
    int wins = 0;
    int losses = 0;
    int position = 0;
    char data[10];
  
    while (fscanf(file, "%s", data) != EOF) {
        if (strcmp(data, "Won") == 0) {
            wins++;
        } else if (strcmp(data, "Lost") == 0) {
            losses++;
        } else if (strncmp(data, "Pos:", 4) == 0) {
            position = atoi(data + 4);
        }
    }
    fclose(file);
    int rating = calculate_rating(wins, losses, position);
    printf("%s has a rating of %d based on:\n%4d wins and \n%4d losses\n   position: %d\n", player_name, rating, wins, losses, position);
}

int main() { 
    printf("WELCOME TO THE WORLD OF ENC MEN'S TENNIS PLAYERS!\n");
    printf("-----------------------------------\n");
  char names[100] = {"Vittal Harith\nAvelino Parrando\nCarlos Gallardo\nFranco Milivinti\nGabriel Guzman\nLuis Hernandez\n"};
  printf("Drum Roll Please!!!!!\n");
  printf("::::::\n%.100s::::::\n", names);

  printf("-----------------------------------\n");
    printf("This program will show you all the statistics and the rating of the player of the 2023 season!\n");
    printf("Enter the name of the player:\n");

    char player_name[20];
    scanf("%s", player_name);
    update_rating(player_name);
    return 0;
}
